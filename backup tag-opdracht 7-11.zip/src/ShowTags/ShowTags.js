import styles from "./showTags.module.css";
import FillTagTitle from "./FillTagTitle";

export default function ShowTags(props) {
    let tagData = props.data;
    let searchText = props.inputText;

    const searchTextLetters = searchText.split("");
    console.log(searchTextLetters);

    // tagData.title moet door geloopt worden om te checken waar de letters zitten.
    // beide als array maken, dan checken, indien match dan index onthouden.

    for (let i = 0; i < tagData.length; i++) {  // loopen door alle tags
        // let tagTitle = tagData[i].title;        // daarvan de titels pakken
        for (let j = 0; j < searchTextLetters.length; j++) {
            if (tagData[i].title == searchTextLetters[j]) {
                // style: text-decoration: underline
                console.log("in if");
                tagData[i].title.style = "text-decoration: underline";
                //vervangen van bijv. t met <span>t</span>? --> maar dan met span-elementen
                // searchTextLetters.map((letter) => { letter.className = "styles.underLine" }); // klopt niet want dit is in de zoekopdracht


            }
        }

    }

    return (
        <>
            <div className={styles.flexContainer}>
                {tagData.map((tag) => {
                    return (
                        <div key={tag.id} className={styles.tagBlock}>
                            <span className={styles.tagTitle}>{tag.title}
                                {/* <FillTagTitle tagData={tagData} seperateLetters={searchTextLetters} /> */}
                                <span className={styles.underline}>t</span>
                                <span className={styles.nounderline}>e</span>
                                <span className={styles.underline}>s</span>
                                <span className={styles.nounderline}>t</span>
                            </span>

                            <span>{tag.body}</span>
                        </div>
                    )
                })}
            </div >
        </>
    )
}