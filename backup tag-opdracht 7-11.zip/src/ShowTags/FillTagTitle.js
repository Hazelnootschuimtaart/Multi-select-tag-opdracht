

export default function FillTagTitle(props) {
    let searchLetters = props.seperateLetters;
    let tagData = props.tagData;

    const titleWords = [];
    const titleLetters = ["a"];
    for (let i = 0; i < tagData.length; i++) {
        titleWords.push(tagData[i].title);

    }

    //poging om de blauwe title van de tag te vullen met span elementen waar de letters van de title in staan. Op die manier kun je aan de juiste spanelementen (oftewel letters) 
    //in css de underline toepassen. Hieronder zijn wat probeersels, in de showtags staat een testvoorbeeld van hoe de zin hierboven werkt, maar moet dus nog uitgewerkt worden voor het echte.

    console.log(titleWords);
    // letter van de een vergelijken met de letter van de ander

    return (
        <>
            {searchLetters.map((character, index) => {
                // if (tagData[index].title.contains(character)) {
                return (
                    <>
                        <span>{titleLetters[index]}</span>
                    </>
                )
            }

                // }
            )
            }
            {/* {yes &&
                <span className={styles.underline}>{letter}</span>
            }
            {no &&
                <span className={styles.notunderline}>{letter}</span>
            } */}


        </>
    )
}