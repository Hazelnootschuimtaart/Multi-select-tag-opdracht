import { useEffect, useState } from 'react';
import styles from './home.module.css';
import ShowTags from './ShowTags/ShowTags';
import SearchBar from './SearchBar/SearchBar';
import data from "./dbTags.json";

export default function Home() {
    const allTags = data.tags;
    const [inputValue, setInputValue] = useState(""); // Typed value
    const [tagData, setTagData] = useState(allTags); // Collection of tags that match the search value

    const inputChange = (inputText) => { // elke keer als je het invoerveld wijzigt wordt dit aangeroepen
        setInputValue(inputText);
        setTagData(allTags);
    }

    useEffect(() => {
        if (inputValue != "") {
            const inputValueLow = inputValue.toLowerCase();
            const filteredTags = (tagData || []).filter((tag) => {
                const tagTitleLow = tag.title.toLowerCase();
                const includesName = tagTitleLow.includes(inputValueLow); //checks if inputvalue == itemname, and returns array with matched items
                return includesName == true;
            });
            setTagData(filteredTags); //Updates state with array that contains matched items (or all if inputvalue is empty)
            // console.log("filteredTags ", filteredTags);
            // console.log("tagData ", tagData);
        }
    }, [inputValue]);

    return (
        <>
            <h4 className={styles.header}>Tags</h4>
            <p className={styles.description}>Add up to 5 tags. Start typing to see suggestions.</p>
            <div style={{ width: "50%" }}>
                <SearchBar value={inputValue} handleClick={(value) => { inputChange(value) }} />
                {inputValue != "" &&
                    <ShowTags inputText={inputValue} data={tagData} />
                }
            </div>

        </>
    )
}