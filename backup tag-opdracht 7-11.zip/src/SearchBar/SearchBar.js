import styles from './searchBar.module.css';

export default function SearchBar(props) {

    let inputValue = props.value;

    const handleChange = (e) => {
        props.handleClick(e.target.value);
    };

    return (
        <>
            <input type='text' className={styles.inputElement} value={inputValue} onChange={(e) => { handleChange(e) }}></input>
        </>
    )
}