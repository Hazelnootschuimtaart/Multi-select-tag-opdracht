import styles from './searchBar.module.css';

export default function SearchBar(props) {
    let selectedTags = props.clickedArray;
    let inputValue = props.value;
    let titleClickedTag = props.clickedTag;
    // const selectedTags = [];
    if (titleClickedTag != "") {
        console.log(`searchbar passed ${titleClickedTag}`);
        // selectedTags.push(titleClickedTag);
        console.log(selectedTags);
    }

    const handleChange = (e) => {
        props.handleChange(e.target.value);
    };

    return (
        <>
            <div className={styles.searchBarContainer}>

                {selectedTags.length !== 0 &&
                    selectedTags.map((tag, index) => {
                        return (
                            <span key={index} className={styles.tagSpan}>{tag}<span className={styles.xButton}>x</span></span>
                        )
                    })
                }
                <input type='text' className={styles.inputElement} value={inputValue} onChange={(e) => { handleChange(e) }}></input>
            </div>
        </>
    )
}