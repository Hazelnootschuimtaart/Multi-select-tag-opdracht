import { useEffect, useState } from 'react';
import styles from './home.module.css';
import ShowTags from './ShowTags/ShowTags';
import ShowNoTags from './ShowNoTags/ShowNoTags';
import SearchBar from './SearchBar/SearchBar';
import data from "./dbTags.json";
import { click } from '@testing-library/user-event/dist/click';

export default function Home() {
    const allTags = data.tags;
    const [inputValue, setInputValue] = useState(""); // Typed value in searchbar
    const [tagData, setTagData] = useState(allTags); // Collection of tags that match the search value
    const [clickedTag, setClickedTag] = useState("");
    const selectedTags = [];

    const inputChange = (inputText) => { // this is called if inputfield changes
        setInputValue(inputText);
        setTagData(allTags);
    }

    // hiermee bezig nu, proberen om meerdere tags in de input balk te krijgen, maar de selectedTags array heeft op de een of andere manier nooit meer dan één item.
    useEffect(() => {
        if (clickedTag != "remove") {
            selectedTags.push(clickedTag);
        }
    })

    // filters the tags that include the inputvalue and updates the tagData state to only show the ones that match with the inputvalue
    useEffect(() => {
        if (inputValue !== "") {
            const inputValueLow = inputValue.toLowerCase();
            const filteredTags = (tagData || []).filter((tag) => {
                const tagTitleLow = tag.title.toLowerCase();
                const includesName = tagTitleLow.includes(inputValueLow); //checks if inputvalue == itemname, and returns array with matched items
                return includesName === true;
            });
            setTagData(filteredTags); //Updates state with array that contains matched items (or all if inputvalue is empty)
        }
    }, [inputValue]);

    return (
        <>
            <h4 className={styles.header}>Tags</h4>
            <p className={styles.description}>Add up to 5 tags. Start typing to see suggestions.</p>
            <div className={styles.searchContainer} style={{ width: "55%" }}>
                <SearchBar value={inputValue} handleChange={(value) => { inputChange(value) }} clickedTag={clickedTag} clickedArray={selectedTags} />
                {inputValue.length !== 0 &&
                    <ShowTags inputText={inputValue} data={tagData} clickedElement={(title) => { setClickedTag(title) }} />
                }
                {tagData.length === 0 &&
                    <ShowNoTags />
                }
            </div>

        </>
    )
}

//queryselector op het input element van de searchbar, met .inputElement::before? Kan dat?
// met useRef staat op internet https://stackoverflow.com/questions/66401438/what-should-i-use-instead-of-document-queryselector-when-using-react