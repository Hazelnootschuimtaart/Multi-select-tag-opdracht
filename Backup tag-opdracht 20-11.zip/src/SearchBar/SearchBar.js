import styles from './searchBar.module.css';

export default function SearchBar(props) {
    let inputValue = props.value;
    let clickedTags = props.clickedTags;

    const handleChange = (e) => {
        props.handleChange(e.target.value);
    };

    return (
        <>
            <div className={styles.searchBarContainer}>
                {/* <span>Test</span> */}
                {clickedTags.map((tag, index) => {
                    return (
                        <span key={index} className={styles.tagSpan}>{tag}<span className={styles.xButton}>x</span></span>
                    )
                })
                }
                <input type='text' className={styles.inputElement} value={inputValue} onChange={(e) => { handleChange(e) }}></input>
            </div>
        </>
    )
}
